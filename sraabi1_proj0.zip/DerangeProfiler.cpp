/**
 * A program to profile derangement algorithms, a naive implementation
 * and a fast version of the algorithm. This also calculates the run times
 * of these implementations
 * !n = n!(1/0! - 1/1! + 1/2! - 1/3! + 1/4! + ... 1/n!)
 * @author William Duncan, Sadman Raabith
 * @see Derangement.h
 * <pre>
 * Date: 9/9/2024
 * Course: csc 3102 section 1
 * Project # 0
 * Instructor: Dr. Duncan
 * </pre>
 */

#include <iostream>
#include <chrono>
#include <iomanip>
#include "Derangement.h"

using namespace std;
using namespace std::chrono;

int main()
{
	//value of n
	int n1 , n2;
	cout<<"Enter two non-negative integers-> ";
	cin >> n1;
	cin>> n2;
/*
	auto start = high_resolution_clock::now();

*/
	cout<<"Using Fast Derangement:"<<endl;
	cout<<"!"<<n1<<" = "<<Derangement::fastDerange(n1)<<endl; //uses header file for fast derangements liek shown in the sample run
	cout<<"!"<<n2<<" = "<<Derangement::fastDerange(n2)<<endl;

	cout<<"Using Naive Derangement: "<<endl;
	cout<<"!"<<n1<<" = "<<Derangement::naiveDerange(n1)<<endl;
	cout<<"!"<<n2<<" = "<<Derangement::naiveDerange(n2)<<endl;



	double n[] = {20,40,60,80,100,120,140,160}; //outlined in the handout

	int num_elements = sizeof(n) / sizeof(n[0]); //finds the len of n

	 cout << setw(10) << "n"
	         << setw(15) << "!n (naive)"
	         << setw(20) << "Time (ns)"
	         << setw(25) << "!n (fast)"
	         << setw(30) << "Time (ns)" << endl; //sets up the header for the table


	for(int i = 0; i<num_elements; i++){
//calculates the time for naive derangements and stores for every element in n array
		auto start_naive = high_resolution_clock::now();
		double result_naive = Derangement::naiveDerange(n[i]);
		auto stop_naive = high_resolution_clock::now();

		auto duration_naive = duration_cast<nanoseconds>(stop_naive-start_naive);

// same calculation but for fast derangements
		auto start_fast = high_resolution_clock::now();
		double result_fast = Derangement::fastDerange(n[i]);
		auto stop_fast = high_resolution_clock::now();
		auto duration_fast = duration_cast<nanoseconds>(stop_fast-start_fast);
//was checking the results with the following codes
		/*
		cout<<"time taken by function: "<<duration.count()<<" nanoseconds"<<endl;

		cout<<"time taken by function: "<<duration.count()<<" nanoseconds"<<endl;
		cout<<"the number of naive derangements:"<<result<<endl;
		*/
//sets up the table, the setwidth was set according to visual appearance. increments of 10 was too large for the screen.
		cout << setw(10) << n[i]<< setw(15) << result_naive << setw(20) << duration_naive.count()
		             << setw(25) << result_fast
		             << setw(30) << duration_fast.count() << endl;
	}

   return 0;

}
		
