/**
 * Implementations for a naive algorithm and a fast algorithm that
 * count the number of derangements of a set given its cardinality.
 * Sadman completed the implementations of the two derangement
 * functions.
 * @author William Duncan, Sadman Raabith
 * <pre>
 * Date: 9/9/2024
 * Course: csc 3102 section 1
 * Project # 0
 * Instructor: Dr. Duncan
 * </pre>
 */

#include <iostream>
#include <cmath>

using namespace std; 
 
class Derangement
{
    public:
       /**
        * Computes the number of derangements of a set
        * @param n the size of the set
        * @return the number of derangements of a set with the specified size
        * @throws invalid_argument exception when n is negative
        */
       static double fastDerange(int n)
       {
    	   double d; //d = number of derangements
           //Implement this function
    	   if  (n < 0){
    	   		throw invalid_argument("Undefined"); //throws for error
    	   	}
    	   else if(n == 0){
    		   return d = 1;
    	   }

    	   else {
    		   double term = -1;
    		   double sum = 0;

    		   for(int i=2; i<= n; i++){ //basic copy paste for the logic from the documentation
    			   term = - term / i;
    			   sum = sum + term;
    		   }
    		   d = sum / abs(term);
    		   //cout << "The value for fast derangement: " << sum / abs(term) << endl;
    		   //return sum/abs(term);
    	   }
    	   return d;

       }

       /**
        * Computes the number of derangements of a set
        * @param n the size of the set
        * @return the number of derangements of a set with the specified size
        * @throws invalid_argument exception when n is negative
        */       
       static double naiveDerange(int n)
       {
           //Implement this function
    	   double d; // the number of derangements
    	   if (n < 0) {
    		   throw invalid_argument("Undefined"); //throws exception
    	   }
    	   else if (n == 0) {
    		   return 1;
    	   }

    	   else {// the logic is basically outlined in the handout
    		   double sum = 0;
    		   double sign = -1;
    		   double factRcp = 1;
    		   for (int i = 2; i <= n; i++) {
    			   sign = -sign;
    			   factRcp = 1;
    			   for(int k = 1;k<=i; k++){
    				   factRcp = factRcp/k;
    			   }
    			   sum += sign * factRcp;
    		   }


    		   d = sum / factRcp;
    	       }
    	   return d;
       }

};
